﻿using System.Collections.Generic;
using System.Net.Http;
using System.Threading.Tasks;
using StarWarsApp.Models;
using Newtonsoft.Json;

namespace StarWarsApp
{
    public static class SwapiService
    {
        private static readonly HttpClient httpClient = new HttpClient();

        public static async Task<List<PeopleModel>> GetPeopleAsync()
        {
            var response = await httpClient.GetStringAsync("https://swapi.dev/api/people/");
            var result = JsonConvert.DeserializeObject<SwapiResponsePeople>(response);
            return result.Results;
        }

        public static async Task<PlanetModel> GetPlanetAsync(string url)
        {
            var response = await httpClient.GetStringAsync(url);
            var result = JsonConvert.DeserializeObject<PlanetModel>(response);
            return result;
        }

        public static async Task<VehicleModel> GetVehicleAsync(string url)
        {
            var response = await httpClient.GetStringAsync(url);
            var result = JsonConvert.DeserializeObject<VehicleModel>(response);
            return result;
        }

        public static async Task<StarShipModel> GetStarShipAsync(string url)
        {
            var response = await httpClient.GetStringAsync(url);
            var result = JsonConvert.DeserializeObject<StarShipModel>(response);
            return result;
        }
    }

    public class SwapiResponsePeople
    {
        public List<PeopleModel> Results { get; set; }
    }

}
