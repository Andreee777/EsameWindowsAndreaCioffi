﻿using System;
using System.Collections.Generic;
using System.Net.Http;
using System.Threading.Tasks;
using Windows.UI.Xaml;
using Windows.UI.Xaml.Controls;
using StarWarsApp.Models;
using Windows.UI.Xaml.Input;
using Windows.UI.Xaml.Media;
using System.Collections.ObjectModel;
using Windows.UI.Xaml.Data;
using System.Linq;
using System.Diagnostics;
using Windows.UI.Xaml.Documents;
using System.Numerics;
using Windows.Devices.Enumeration;
using Newtonsoft.Json;
using Windows.Storage;

namespace StarWarsApp
{
    public sealed partial class MainPage : Page
    {

        public List<PeopleModel> allPeople { get; set; }
        public List<PlanetModel> allPlanets { get; set; }
        public List<VehicleModel> allVehicles { get; set; }
        public List<StarShipModel> allStarShips { get; set; }
        public Boolean searchSelection { get; set; } = true;
        public Grid listSelection { get; set; }

        public MainPage()
        {
            this.InitializeComponent();

            allPeople = new List<PeopleModel> { };
            allPlanets = new List<PlanetModel> { };
            allVehicles = new List<VehicleModel> { };
            allStarShips = new List<StarShipModel> { };

            LoadPeopleData();

        }

        private void onComboBoxChange(object sender, SelectionChangedEventArgs e)
        {
            var selectedItem = MyComboBox.SelectedItem as ComboBoxItem;

            if (selectedItem != null)
            {
                string selectedContent = selectedItem.Content.ToString();
                if(selectedContent.Equals("Nome"))
                {
                    searchSelection = true;
                } else
                {
                    searchSelection = false;
                }
            }
        }

        private async void LoadPeopleData()
        {
            BorderPeople.Visibility = Visibility.Collapsed;
            LoaderPeople.Visibility = Visibility.Visible;
            var people = await SwapiService.GetPeopleAsync();
            foreach (var person in people)
            {
                allPeople.Add(person);
            }
            PeopleListBox.ItemsSource = allPeople.ToArray();
            BorderPeople.Visibility = Visibility.Visible;
            LoaderPeople.Visibility = Visibility.Collapsed;
        }

        private async void Search(object sender, TextChangedEventArgs e)
        {
            LoaderPeopleInfoRing.IsActive = false;
            BorderPeople.Visibility = Visibility.Collapsed;
            LoaderPeople.Visibility= Visibility.Visible;
            string filter = SearchBox.Text.ToLower();
            PeopleModel[] temp = allPeople.ToArray();
            if (searchSelection)
            {
                PeopleListBox.ItemsSource = temp.Where(person =>
                person.name.ToLower().Contains(filter.ToLower()))
                .ToArray();

            }
            else
            {
                List<string> namesList = new List<string>();
                foreach (var person in temp)
                {
                    var planet = await SwapiService.GetPlanetAsync(person.homeworld);
                    if (planet.name.ToLower().Contains(filter.ToLower()))
                    {
                        namesList.Add(person.name);
                    }
                }

                PeopleListBox.ItemsSource = temp.Where(person =>
                namesList.Contains(person.name))
                .ToArray();
            }

            await Task.Delay(250);

            BorderPeople.Visibility = Visibility.Visible;
            LoaderPeople.Visibility = Visibility.Collapsed;

        }

        private async void ListItemChanged(object sender, SelectionChangedEventArgs e)
        {
            BorderPeopleInfo.Visibility = Visibility.Collapsed;
            LoaderPeopleInfo.Visibility = Visibility.Visible;
            BorderPeopleInfoNotFound.Visibility = Visibility.Collapsed;

            foreach (var child in Vehicles.Children.ToList())
            {
                Vehicles.Children.Remove(child);
            }

            foreach (var child in StarShips.Children.ToList())
            {
                StarShips.Children.Remove(child);
            }

            if (listSelection != null)
            {
                listSelection.BorderBrush = new Windows.UI.Xaml.Media.SolidColorBrush(Windows.UI.Colors.White);
            }

            var selectedItem = PeopleListBox.SelectedItem;
            var listBoxItem = PeopleListBox.ContainerFromItem(selectedItem) as ListBoxItem;
            try
            {
                TextBlock textBlock = FindVisualChild<TextBlock>(listBoxItem);
                var grid = textBlock.Parent as Grid;

                listSelection = grid;

                grid.BorderBrush = new Windows.UI.Xaml.Media.SolidColorBrush(Windows.UI.Colors.Violet);

                LoaderPeopleInfoRing.IsActive = true;

                var person = (PeopleModel)(textBlock).DataContext;

                var planet = await SwapiService.GetPlanetAsync(person.homeworld);

                var check = false;

                foreach (var p in allPlanets.ToArray())
                {
                    if (p.name.Equals(planet.name))
                    {
                        check = true;
                    }
                }

                if (!check)
                {
                    allPlanets.Add(planet);
                }

                name.Text = $"Name: {person.name}";
                height.Text = $"Height: {person.height}";
                mass.Text = $"Mass: {person.mass}";
                skin_color.Text = $"Skin Color: {person.skin_color}";
                birth_year.Text = $"Birth Year: {person.birth_year}";
                gender.Text = $"Gender: {person.gender}";
                planetBlock.Text = $"Planet:";
                planetValue.Text = $"{planet.name}";

                Vehicles.Children.Add(new TextBlock
                {
                    Text = "Vehichles:",
                    FontSize = 18,
                    FontWeight = Windows.UI.Text.FontWeights.Bold,
                    Foreground = new Windows.UI.Xaml.Media.SolidColorBrush(Windows.UI.Colors.White)
                });

                int iterationIndex = 0;
                foreach (var v in person.vehicles)
                {
                    StackPanel st1 = new StackPanel { Orientation = Orientation.Horizontal };
                    iterationIndex++;
                    var vehicle = await SwapiService.GetVehicleAsync(v);
                    var check2 = false;

                    foreach (var vc in allVehicles.ToArray())
                    {
                        if (vc.name.Equals(vehicle.name))
                        {
                            check2 = true;
                        }
                    }

                    if (!check2)
                    {
                        allVehicles.Add(vehicle);
                    }

                    TextBlock vehicleTextBlock = new TextBlock
                    {
                        Text = vehicle.name,
                        FontSize = 18,
                        FontWeight = Windows.UI.Text.FontWeights.Bold,
                        Foreground = new Windows.UI.Xaml.Media.SolidColorBrush(Windows.UI.Colors.Violet),
                        Padding = new Windows.UI.Xaml.Thickness(25, 0, 0, 0),

                    };
                    vehicleTextBlock.Tapped += vehicleClick;
                    vehicleTextBlock.PointerMoved += PointerMoved;
                    vehicleTextBlock.PointerExited += PointerExited;

                    st1.Children.Add(vehicleTextBlock);

                    if (iterationIndex < person.vehicles.Length)
                    {
                        st1.Children.Add(new TextBlock
                        {
                            Text = ",",
                            FontSize = 18,
                            FontWeight = Windows.UI.Text.FontWeights.Bold,
                            Foreground = new Windows.UI.Xaml.Media.SolidColorBrush(Windows.UI.Colors.White)
                        });
                    }
                    Vehicles.Children.Add(st1);
                }

                if (person.vehicles.Length == 0)
                {
                    Vehicles.Children.Add(new TextBlock
                    {
                        Text = "Nessun elemento",
                        FontSize = 18,
                        FontWeight = Windows.UI.Text.FontWeights.Bold,
                        Foreground = new Windows.UI.Xaml.Media.SolidColorBrush(Windows.UI.Colors.Red),
                        Padding = new Windows.UI.Xaml.Thickness(5, 0, 0, 0),

                    });

                }

                int iterationIndex2 = 0;
                StarShips.Children.Add(new TextBlock
                {
                    Text = "StarShips:",
                    FontSize = 18,
                    FontWeight = Windows.UI.Text.FontWeights.Bold,
                    Foreground = new Windows.UI.Xaml.Media.SolidColorBrush(Windows.UI.Colors.White)
                });

                foreach (var s in person.starships)
                {
                    StackPanel st2 = new StackPanel();
                    st2.Orientation = Orientation.Horizontal;
                    iterationIndex2++;
                    var startShip = await SwapiService.GetStarShipAsync(s);
                    var check3 = false;

                    foreach (var ss in allStarShips.ToArray())
                    {
                        if (ss.name.Equals(startShip.name))
                        {
                            check3 = true;
                        }
                    }

                    if (!check3)
                    {
                        allStarShips.Add(startShip);
                    }

                    TextBlock starShipTextBlock = new TextBlock
                    {
                        Text = startShip.name,
                        FontSize = 18,
                        FontWeight = Windows.UI.Text.FontWeights.Bold,
                        Foreground = new Windows.UI.Xaml.Media.SolidColorBrush(Windows.UI.Colors.Violet),
                        Padding = new Windows.UI.Xaml.Thickness(25, 0, 0, 0),

                    };

                    starShipTextBlock.PointerMoved += PointerMoved;
                    starShipTextBlock.PointerExited += PointerExited;
                    starShipTextBlock.Tapped += starShipClick;

                    st2.Children.Add(starShipTextBlock);

                    if (iterationIndex2 < person.starships.Length)
                    {
                        st2.Children.Add(new TextBlock
                        {
                            Text = ",",
                            FontSize = 18,
                            FontWeight = Windows.UI.Text.FontWeights.Bold,
                            Foreground = new Windows.UI.Xaml.Media.SolidColorBrush(Windows.UI.Colors.White)
                        }
                        );
                    }
                    StarShips.Children.Add(st2);
                }

                if (person.starships.Length == 0)
                {
                    StarShips.Children.Add(new TextBlock
                    {
                        Text = "Nessun elemento",
                        FontSize = 18,
                        FontWeight = Windows.UI.Text.FontWeights.Bold,
                        Foreground = new Windows.UI.Xaml.Media.SolidColorBrush(Windows.UI.Colors.Red),
                        Padding = new Windows.UI.Xaml.Thickness(5, 0, 0, 0),

                    });

                }

                await Task.Delay(250);

                LoaderPeopleInfoRing.IsActive = false;
                BorderPeopleInfo.Visibility = Visibility.Visible;
                LoaderPeopleInfo.Visibility = Visibility.Collapsed;
            }
            catch (Exception ex)
            {
                BorderPeopleInfoNotFound.Visibility = Visibility.Visible;
            }

        }

        private T FindVisualChild<T>(DependencyObject parent) where T : DependencyObject
        {
            if (parent is T)
                return (T)parent;

            for (int i = 0; i < VisualTreeHelper.GetChildrenCount(parent); i++)
            {
                var child = VisualTreeHelper.GetChild(parent, i);

                var result = FindVisualChild<T>(child);
                if (result != null)
                    return result;
            }
            return null;
        }

        private async void Save(object sender, TappedRoutedEventArgs e)
        {
            PeopleModel[] actualData = (PeopleModel[]) PeopleListBox.ItemsSource;

            string jsonData = JsonConvert.SerializeObject(actualData);

            StorageFolder localFolder = ApplicationData.Current.LocalFolder;

            StorageFile jsonFile = await localFolder.CreateFileAsync("people.json", CreationCollisionOption.ReplaceExisting);

            await FileIO.WriteTextAsync(jsonFile, jsonData);

            int iterationIndex = 0;
            string stringa = "[";
            foreach (var person in actualData)
            {
                iterationIndex++;
                stringa += person.name;
                if(iterationIndex < actualData.Length)
                {
                    stringa += ", ";
                }
            }
            stringa += "]";
            stringa += " sono stati salvati nel file people.json";
            info.Text = stringa;

            OperationDialog.ShowAsync();
        }

        private async void Load(object sender, TappedRoutedEventArgs e)
        {
            StorageFolder localFolder = ApplicationData.Current.LocalFolder;

            StorageFile jsonFile = await localFolder.GetFileAsync("people.json");

            string jsonData = await FileIO.ReadTextAsync(jsonFile);

            List<PeopleModel> people = JsonConvert.DeserializeObject<List<PeopleModel>>(jsonData);

            allPeople = people;
            PeopleListBox.ItemsSource = allPeople.ToArray();

            int iterationIndex = 0;
            string stringa = "[";
            foreach (var person in people)
            {
                iterationIndex++;
                stringa += person.name;
                if (iterationIndex < people.Capacity)
                {
                    stringa += ", ";
                }
            }
            stringa += "]";
            stringa += " sono stati caricati dal file people.json";
            info.Text = stringa;

            OperationDialog.ShowAsync();
        }

        private void starShipClick(object sender, TappedRoutedEventArgs e)
        {
            TextBlock tappedTextBlock = sender as TextBlock;

            foreach (var s in allStarShips.ToArray())
            {
                if (s.name.Equals(tappedTextBlock.Text))
                {
                    StarShipDialog.Title = new TextBlock
                    {
                        Text = s.name,
                        FontWeight = Windows.UI.Text.FontWeights.Bold,
                        FontSize = 20
                    };
                    model_starship.Text = $"Model: {s.model}";
                    manufacturer.Text = $"Manufacturer: {s.manufacturer}";
                    max_atmosphering_speed_starship.Text = $"Max Atmosphering Speed: {s.max_atmosphering_speed}";
                    starship_class.Text = $"StarShip Class: {s.starship_class}";
                }
            }

            StarShipDialog.ShowAsync();
        }

        private void vehicleClick(object sender, TappedRoutedEventArgs e)
        {
            TextBlock tappedTextBlock = sender as TextBlock;

            foreach (var v in allVehicles.ToArray())
            {
                if (v.name.Equals(tappedTextBlock.Text))
                {
                    VehicleDialog.Title = new TextBlock
                    {
                        Text = v.name,
                        FontWeight = Windows.UI.Text.FontWeights.Bold,
                        FontSize = 20
                    };
                    model_vehicle.Text = $"Model: {v.model}";
                    vehicle_class.Text = $"Vehicle Class: {v.vehicle_class}";
                    max_atmosphering_speed_vehicle.Text = $"Max Atmosphering Speed: {v.max_atmosphering_speed}";
                }
            }

            VehicleDialog.ShowAsync();
        }


        private void planetClick(object sender, TappedRoutedEventArgs e)
        {
            TextBlock tappedTextBlock = sender as TextBlock;

            foreach (var p in allPlanets.ToArray())
            {
                if (p.name.Equals(tappedTextBlock.Text))
                {
                    PlanetDialog.Title = new TextBlock
                    {
                        Text = p.name,
                        FontWeight = Windows.UI.Text.FontWeights.Bold,
                        FontSize = 20
                    };
                    gravity.Text = $"Gravity: {p.gravity}";
                    terrain.Text = $"Terrain: {p.terrain}";
                    surface_water.Text = $"Surface Water: {p.surface_water}";
                    population.Text = $"Population: {p.population}";
                }
            }

            PlanetDialog.ShowAsync();
        }

        private void PointerMoved(object sender, Windows.UI.Xaml.Input.PointerRoutedEventArgs e)
        {
            var handCursor = new Windows.UI.Core.CoreCursor(Windows.UI.Core.CoreCursorType.Hand, 0);
            Window.Current.CoreWindow.PointerCursor = handCursor;
        }

        private void PointerExited(object sender, Windows.UI.Xaml.Input.PointerRoutedEventArgs e)
        {
            var arrowCursor = new Windows.UI.Core.CoreCursor(Windows.UI.Core.CoreCursorType.Arrow, 0);
            Window.Current.CoreWindow.PointerCursor = arrowCursor;
        }


    }

}
